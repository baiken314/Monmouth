package edu.monmouth.s1175816.studentlist

interface OnItemClickListener {
    fun onViewItemClicked(student: Student)
}