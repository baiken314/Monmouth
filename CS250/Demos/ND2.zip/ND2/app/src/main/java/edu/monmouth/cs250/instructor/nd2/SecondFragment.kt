package edu.monmouth.cs250.instructor.nd2

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.fragment_second.*



/**
 * A simple [Fragment] subclass.
 */
class SecondFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_second, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        (activity as AppCompatActivity).supportActionBar?.title = "Second Fragment"
    }

    interface OnFragmentInteractionListener {
        fun onFragmentInteraction (uri: Uri)
    }

    override fun onStart() {
        super.onStart()
        arguments?.let {
            var args = SecondFragmentArgs.fromBundle(it)
            argText.text = args.message
        }
    }
}
