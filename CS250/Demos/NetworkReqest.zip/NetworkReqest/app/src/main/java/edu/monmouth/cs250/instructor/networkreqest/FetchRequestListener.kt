package edu.monmouth.cs250.instructor.networkreqest

interface FetchRequestListener {
    fun fetchCompleted()
}