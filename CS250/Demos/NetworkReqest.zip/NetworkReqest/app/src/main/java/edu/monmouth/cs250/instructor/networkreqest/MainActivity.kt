package edu.monmouth.cs250.instructor.networkreqest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_main.*

import androidx.core.net.toUri
import okhttp3.*

import java.io.IOException
import java.net.URLEncoder

class MainActivity : AppCompatActivity(), FetchRequestListener {

    private val weather = WeatherModel(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val gobutton = findViewById (R.id.go) as Button

        addRightCancelDrawable(city)
//        city.onRightDrawableClicked {
//            it.text.clear()
//        }

        city.makeClearableEditText(null, null)

        gobutton.setOnClickListener {

                println ("get weather")
                val city = city.text.toString()
                fetchJSON(city)

        }

    }

    fun fetchJSON (city : String) {

        weather.getWeather(city)
    }

    override fun fetchCompleted() {
        val w = weather.currentWeatherConditions
        runOnUiThread {
            println ("City: ${w.city}  Current Temp: ${w.temperature} Current Sky: ${w.skyContion}")
            temperature.text = w.temperature.toString()
            sky.text = w.skyContion
        }
    }

    private fun addRightCancelDrawable(editText: EditText) {
        val cancel = ContextCompat.getDrawable(this, R.drawable.ic_cancel_black_24dp)
        cancel?.setBounds(0,0, cancel.intrinsicWidth, cancel.intrinsicHeight)
        editText.setCompoundDrawables(null, null, cancel, null)
    }
}
