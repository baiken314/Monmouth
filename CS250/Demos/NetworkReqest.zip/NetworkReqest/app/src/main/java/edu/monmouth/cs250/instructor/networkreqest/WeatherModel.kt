package edu.monmouth.cs250.instructor.networkreqest

import android.content.Context
import com.google.gson.Gson
import okhttp3.*
import java.io.IOException
import java.util.*


/*
"main": {
    "temp": 58.42,
    "feels_like": 46.89,
    "temp_min": 57.2,
    "temp_max": 59,
    "pressure": 1012,
    "humidity": 35
  }
 */
data class Weather (val id: Int, val main: String, val description: String, val icon: String)
data class Main (val temp: Double, val feels_like: Double, val temp_min: Double,
                 val temp_max: Double, val pressure: Double, val humidity: Double )
data class Sys (val type: Int, val id: Int, val country: String, val sunrise: Int, val sunset: Int)
data class CurrentWeather (val name: String,  val weather: List<Weather>, val main: Main, val sys: Sys, val timezone: Int)
data class CurrentWeatherConditions (val city: String, val temperature: Double, val skyContion: String)

class WeatherModel (val context: Context) {

    public lateinit var currentWeather: CurrentWeather
    public lateinit var currentWeatherConditions: CurrentWeatherConditions

    fun getWeather (city: String) {

        val weatherUrlStr =
            "https://api.openweathermap.org/data/2.5/weather?units=imperial&appid=0b315084c3763ba4b68013a80a614b47&q="
        val args = city.replace(" ", "%20")

        val client = OkHttpClient()
        val request = Request.Builder().url(weatherUrlStr + args).build()
        client.newCall(request).enqueue(object: Callback {

            override fun onFailure(call: Call, e: IOException) {
                println ("request failed")
            }

            override fun onResponse(call: Call, response: Response) {
                println ("we have a valid response")
                val jsonString = response.body?.string()
                println (jsonString)
                jsonString?.let {
                    jsonToWeatherObject(it)
                    val c = context as FetchRequestListener
                    c.fetchCompleted()
                }
            }

        })
    }

    fun jsonToWeatherObject (jsonStr: String) {
        currentWeather = Gson().fromJson(jsonStr, CurrentWeather::class.java)

        currentWeatherConditions = CurrentWeatherConditions(currentWeather.name,
            currentWeather.main.temp,
            currentWeather.weather[0].description)
    }
}



//        println (currentWeather.name)
//        println (currentWeather.main.temp)
//        println (currentWeather.weather[0].description)
//        println (currentWeather.sys.sunrise)
//        println (currentWeather.sys.sunset)
//        val localsunrise = currentWeather.sys.sunrise // + currentWeather.timezone
//        val localsunset = currentWeather.sys.sunset // + currentWeather.timezone
//
//
//        var ds = Date (localsunrise.toLong() * 1000)
//
//        var hh = ds.hours
//        var mm = ds.minutes
//        println ("$hh:$mm")
//
//        ds = Date (localsunset.toLong() * 1000)
//         hh = ds.hours
//         mm = ds.minutes
//        println ("$hh:$mm")


//  val weatherUrlString = "https://api.openweathermap.org/data/2.5/weather?units=imperial&appid=0b315084c3763ba4b68013a80a614b47"
// api.openweathermap.org/data/2.5/weather?q={city name}&appid={your api key}
// 0b315084c3763ba4b68013a80a614b47