Rails.application.routes.draw do

  # redefine root route as view_all action
  root 'entries#view_all'

  # define route to use new view_all controller action
  get '/entries/view_all' => 'entries#view_all'

  resources :entries
  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html
end
