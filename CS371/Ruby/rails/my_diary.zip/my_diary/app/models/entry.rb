class Entry < ApplicationRecord
end
